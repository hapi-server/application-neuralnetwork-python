"""
Author: Travis Hammond
©️ 2022 The Johns Hopkins University Applied Physics Laboratory LLC.
"""

MODEL_ENGINE = 'TORCH'
# MODEL_ENGINE = 'TENSORFLOW'
